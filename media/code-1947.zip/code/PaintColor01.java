/*PaintColor01.java 12/12/99
Copyright 1999, R.G.Baldwin

Illustrates use of a Paint object to fill a Shape with
a solid color.

Draws a 4-inch by 4-inch Frame on the screen.

Translates the orgin to the center of the Frame.

Draws a pair of X and Y-axes centered on the new origin.

Draws one 2-inch diameter circle in each quadrant.

Fills upper left circle with solid red.
Fills upper right circle with solid green
Fills lower left circle with solid blue
Fills lower right circle with solid yellow

Whether the dimensions in inches come out right or not
depends on whether the method getScreenResolution()
returns the correct resolution for your screen.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

class PaintColor01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class PaintColor01

class GUI extends Frame{
  int res;//store screen resolution here
  static final int ds = 72;//default scale, 72 units/inch
  static final int hSize = 4;//horizonal size = 4 inches
  static final int vSize = 4;//vertical size = 4 inches
  
  GUI(){//constructor
    //Get screen resolution
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
    //Set Frame size
    this.setSize(hSize*res,vSize*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  //-----------------------------------------------------//
  
  //Override the paint() method
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    Graphics2D g2 = (Graphics2D)g;
    
    //Scale device space to produce inches on the screen
    // based on actual screen resolution.
    g2.scale((double)res/72,(double)res/72);

    //Translate origin to center of Frame
    g2.translate((hSize/2)*ds,(vSize/2)*ds);
    
    //Draw x-axis
    g2.draw(new Line2D.Double(-1.5*ds,0.0,1.5*ds,0.0));
    //Draw y-axis
    g2.draw(new Line2D.Double(0.0,-1.5*ds,0.0,1.5*ds));
    
    //Upper left quadrant, Solid red fill
    Ellipse2D.Double circle1 = new Ellipse2D.Double(
                            -2.0*ds,-2.0*ds,2.0*ds,2.0*ds);
    g2.setPaint(new Color(255,0,0));//red
    g2.fill(circle1);
    g2.draw(circle1);
    
    //Upper right quadrant, Solid green fill
    Ellipse2D.Double circle2 = new Ellipse2D.Double(
                             0.0*ds,-2.0*ds,2.0*ds,2.0*ds);
    g2.setPaint(new Color(0,255,0));//green
    g2.fill(circle2);
    g2.draw(circle2);
    
    //Lower left quadrant, Solid blue fill
    Ellipse2D.Double circle3 = new Ellipse2D.Double(
                             -2.0*ds,0.0*ds,2.0*ds,2.0*ds);
    g2.setPaint(new Color(0,0,255));//blue
    g2.fill(circle3);
    g2.draw(circle3);
    
    //Lower right quadrant, Solid yellow fill
    Ellipse2D.Double circle4 = new Ellipse2D.Double(
                              0.0*ds,0.0*ds,2.0*ds,2.0*ds);
    g2.setPaint(new Color(255,255,0));//yellow
    g2.fill(circle4);
    g2.draw(circle4);    

  }//end overridden paint()
    
}//end class GUI
//=======================================================//