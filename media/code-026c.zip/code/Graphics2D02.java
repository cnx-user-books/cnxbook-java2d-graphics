/*Graphics2D02.java 12/12/99
Copyright 1999, R.G.Baldwin

Illustrates use of the Graphics2D class, the
Rectangle2D class, and an object of the AffineTransform
class.

The object of the AffineTransform class is used to 
compensate for the difference in actual screen resolution 
and the default screen resolution of 72 pixels per inch
used by the API.

Illustrates using the default screen resolution and an
AffineTransform based on the actual screen resolution to 
produce a Frame that is two inches on each side containing
a square that is one inch on each side, centered in the 
Frame.

The size of the Frame is based on the actual screen
resolution in pixels per inch.  The drawing of the square 
inside the frame is based on inches scaled by the default
resolution of 72 pixels per inch, with the resulting
square scaled by an AffineTransform that compensates for
the difference in default screen resolution and actual
screen resolution.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;

class Graphics2D02{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Graphics2D02

class GUI extends Frame{
  int res;//store screen resolution here
  
  GUI(){//constructor
    //Get screen resolution
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
                                    
    //Display screen resolution.                                   
    System.out.println(res + " pixels per inch");

    //Set Frame size to two-inches by two-inches
    this.setSize(2*res,2*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  
  //Override the paint() method to draw a one-inch by
  // one-inch square centered in the Frame.
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    // to make the features of the Graphics2D class
    // available
    Graphics2D g2 = (Graphics2D)g;
    
    //Set the transform to a scaling transform that 
    // compensates for the difference in actual screen
    // resolution and the default screen resolution of
    // 72 pixels per inch used in the API
    g2.setTransform(AffineTransform.getScaleInstance(
                           (double)res/72,(double)res/72));

    int ds = 72;//default scale = 72 pixels per inch
    
    //Instantiate and draw an object of the 
    // Rectangle2D.Double class that is centered in the
    // Frame and is one inch on each side.  Center the
    // rectangle in the Frame by placing its upper left-
    // hand corner at a position that is one-half inch to 
    // the right and one-half inch below the upper 
    // left-hand corner of the Frame.  Note that the 
    // default screen resolution of 72 pixels per inch is 
    // used to establish the location and size of the 
    // rectangle in inches.
    g2.draw(new Rectangle2D.Double(
                         0.5*ds, 0.5*ds, 1.0*ds, 1.0*ds));
  }//end overridden paint()
}//end class GUI
//=======================================================//