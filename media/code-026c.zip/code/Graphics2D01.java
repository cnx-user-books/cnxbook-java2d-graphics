/*Graphics2D01.java 12/12/99
Copyright 1999, R.G.Baldwin

Illustrates use of the Graphics2D class and the
Rectangle2D class.

Illustrates getting and displaying screen width, height,
and resolution.

Illustrates using screen resolution to produce a Frame
that is two inches on each side containing a square that
is one inch on each side, centered in the Frame.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;

class Graphics2D01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Graphics2D01

class GUI extends Frame{
  int res;//store screen resolution here
  int width;//store screen width here
  int height;//store screen height here
  
  GUI(){//constructor
    //Get screen resolution, width, and height
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
    width = Toolkit.getDefaultToolkit().
                                     getScreenSize().width;
    height = Toolkit.getDefaultToolkit().
                                    getScreenSize().height;
                                    
    //Display screen resolution, width, and height.                                   
    System.out.println(res + " pixels per inch");
    System.out.println(width + " pixels wide");
    System.out.println(height + " pixels high");

    //Set Frame size to two-inch by two-inch
    this.setSize(2*res,2*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  
  //Override the paint() method to draw a one-inch by
  // one-inch rectangle centered in the Frame.
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    // to make the features of the Graphics2D class
    // available
    Graphics2D g2 = (Graphics2D)g;
    
    //Instantiate and draw an object of the 
    // Rectangle2D.Double class that is centered in the
    // Frame and is one inch on each side.  Center the
    // rectangle in the Frame by placing its upper left-
    // hand corner at a position that is one-half inch to 
    // the right and one-hlf inch below the upper left-hand
    // corner of the Frame.  Note that the screen 
    // resolution in pixels per inch is used to establish
    // the location and size of the rectangle in inches.
    g2.draw(new Rectangle2D.Double(
                         res*0.5,res*0.5,res*1.0,res*1.0));
  }//end overridden paint()
}//end class GUI
//=======================================================//