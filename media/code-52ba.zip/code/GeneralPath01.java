/*GeneralPath01.java 12/12/99
Copyright 1999, R.G.Baldwin

Illustrates use of the GeneralPath class.

Draws a 4-inch by 4-inch Frame on the screen.

Translates the orgin to the center of the Frame.

Draws a pair of X and Y-axes centered on the new origin.

Draws a GeneralPath object on the Frame. The object is
a diamond whose vertices are at plus and minus one-half 
inch on each of the axes.  The vertices are located at 
the N, S, E, and W positions.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;

class GeneralPath01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class GeneralPath01

class GUI extends Frame{
  int res;//store screen resolution here
  static final int ds = 72;//default scale, 72 units/inch
  static final int hSize = 4;//horizonal size = 4 inches
  static final int vSize = 4;//vertical size = 4 inches
  
  GUI(){//constructor
    //Get screen resolution
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
    //Set Frame size
    this.setSize(hSize*res,vSize*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  
  //Override the paint() method
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    Graphics2D g2 = (Graphics2D)g;
    
    //Scale device space to produce inches on the screen
    // based on actual screen resolution.
    g2.scale((double)res/72,(double)res/72);

    //Translate origin to center of Frame
    g2.translate((hSize/2)*ds,(vSize/2)*ds);
    
    //Draw x-axis
    g2.draw(new Line2D.Double(-1.5*ds,0.0,1.5*ds,0.0));
    //Draw y-axis
    g2.draw(new Line2D.Double(0.0,-1.5*ds,0.0,1.5*ds));

    //Use the GeneralPath class to instantiate a diamond 
    // object whose vertices are at plus and minus 
    // one-half inch on each of the axes.  The
    // vertices in the N, S, E, and W positions, centered
    // about the origin.    
    GeneralPath thePath = new GeneralPath();
    thePath.moveTo(0.5f*ds,0.0f*ds);
    thePath.lineTo(0.0f*ds,0.5f*ds);
    thePath.lineTo(-0.5f*ds,0.0f*ds);
    thePath.lineTo(0.0f*ds,-0.5f*ds);
    thePath.closePath();
    
    //Now draw the diamond on the screen
    g2.draw(thePath);

  }//end overridden paint()
    
}//end class GUI
//=======================================================//