/*InnerClasses04.java 12/07/99
Copyright 1999, R.G.Baldwin

Illustrates a static inner class that extends its 
containing class.  This is an illustration of the use of
nested top-level classes similar to that used in the
Graphics 2D API.

The output from the program is:
	
---Hello from object of class OuterClass.NestedDoubleClass
Hello from superclass OuterClass
--Goodbye from object of class OuterClass.NestedDoubleClass
==Hello from object of class OuterClass.NestedFloatClass
Hello from superclass OuterClass
==Goodbye from object of class OuterClass.NestedFloatClass

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/

//This is a class that contains two nested top-level 
// classes
abstract class OuterClass{
	//This method is overridden in each of the nested classes
	void talk(){
		System.out.println("Hello from superclass OuterClass");
	}//end talk
	
	//-----------------------------------------------------//
	//The definitions of two nested top-level classes follow
	
	//nested top-level class
	static class NestedDoubleClass extends OuterClass{
		String theString = "---Hello from object of class "
		                      + "OuterClass.NestedDoubleClass";
		void talk(){//override the talk method
			super.talk();//invoke superclass version
			System.out.println("---Goodbye from object of class "
			                   + "OuterClass.NestedDoubleClass");
		}//end talk()
	}//end class NestedDoubleClass
	
	//nested top-level class
	static class NestedFloatClass extends OuterClass{
		String theString = "==Hello from object of class "
		                       + "OuterClass.NestedFloatClass";
		void talk(){//override the talk method
			super.talk();//invoke superclass version
			System.out.println("==Goodbye from object of class "
			                    + "OuterClass.NestedFloatClass");
		}//end talk()
	}//end class NestedFloatClass

}//end class OuterClass

//=======================================================//
//This is the controlling class that instantiates and
// processes an object from each of the nested top-level
// classes defined above.
class InnerClasses04{
	public static void main(String[] args){
		//Declare a reference variable of type OuterClass
		OuterClass theVar;
		
		//Instantiate and process an object of the subclass
		// named OuterClass.NestedDoubleClass, but refer to 
		// it as type OuterClass.
		theVar = new OuterClass.NestedDoubleClass();
		processTheObject(theVar);

		//Instantiate and process an object of the subclass
		// named OuterClass.NestedFloatClass,  but refer to 
		// it as type OuterClass.
		theVar = new OuterClass.NestedFloatClass();
		processTheObject(theVar);
	}//end main

  static void processTheObject(OuterClass theRefVariable){
  	//Test for the actual type of the incoming reference
  	// variable and downcast as appropriate before using it
  	
		if(theRefVariable instanceof 
		                         OuterClass.NestedDoubleClass){
			System.out.println(
			      ((OuterClass.NestedDoubleClass)theRefVariable).
			                                          theString);
		}//end if(theRefVariable instanceof ...
			
    if(theRefVariable instanceof 
                              OuterClass.NestedFloatClass){
    	System.out.println(
    	        ((OuterClass.NestedFloatClass)theRefVariable).
    	                                           theString);
    }//end if(theRefVariable instanceof ...
    
    theRefVariable.talk();//invoke overridden talk() method
  }//end processTheObject()
}//end controlling class InnerClasses04
//=======================================================//