/*Point01.java 12/07/99
Copyright 1999, R.G.Baldwin

Illustrates use of the static inner classes of the
java.awt.geom.Point2D class.

This program instantiates an object of each of the 
following nested classes and populates the X and Y values 
of those objects with never-ending fractional values 
consisting of never-ending strings of 33333 and 66666.

Point2D.Double
Point2D.Float

The reference to each of the objects is stored in a
reference variable of the type Point2D, which is the
superclass of each of the nested classes.

Then the getX() and getY() methods of the two classes
are used to get and display the values stored in each of 
the objects.  The output from the program is:
	
Data from the object of type Point2D.Double
0.3333333333333333
0.6666666666666666

Data from the object of type Point2D.Float
0.3333333432674408
0.6666666865348816

This output illustrates the manner in which the two 
different nested classes can be used to instantiate a
Point2D object that maintains its coordinate data either as
type double or as type float.

Note that even though the Point2D.Float class stores its
coordinate data as float, the getX() and getY() methods
of that class return the coordinate values as type
double.  The values returned are incorrect beyond about the
seventh significant digit.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.Point2D;

class Point01{
	//Declare two different instance variables, each of
	// type Point2D.
  Point2D doublePointVar;
  Point2D floatPointVar;
  
	public static void main(String[] args){
		//Instantiate a new object of this type containing two
		// instance variables, both of type Point2D.
		Point01 thisObj = new Point01();

    //Instantiate an object of the type Point2D.Double
    // and store a reference to the object in one of the
    // instance variables of the object of this class.
    // Populate the X and Y values of the object with
    // a never-ending fraction of the primitive type 
    // double.		
    thisObj.doublePointVar = 
                           new Point2D.Double(1.0/3,2.0/3);

    //Instantiate an object of the type Point2D.Float
    // and store a reference to the object in one of the
    // instance variables of the object of this class.
    // Populate the X and Y values of the object with
    // a never-ending fraction of the primitive type 
    // float.  Note that a cast is required to cause the
    // division operation to produce a float result 
    // instead of a double result.
	
    thisObj.floatPointVar = 
              new Point2D.Float((float)1.0/3,(float)2.0/3);

    //Get and display the X and Y values stored in each of
    // the objects.  Note that the getX() and getY()
    // methods of the class Point2D.Float return the X
    // and Y coordinate values as type double, but the
    // value is incorrect beyond about the seventh 
    // significant digit.
    System.out.println("Data from the object of type "
                                       + "Point2D.Double");
		System.out.println(thisObj.doublePointVar.getX());
		System.out.println(thisObj.doublePointVar.getY());

    System.out.println("\nData from the object of type "
                                        + "Point2D.Float");
		System.out.println(thisObj.floatPointVar.getX());
		System.out.println(thisObj.floatPointVar.getY());

		
	}//end main


}//end controlling class Point01
//=======================================================//