/*Composite02.java 12/12/99
Copyright 1999, R.G.Baldwin

Identical to Composite01 except that it uses gradient 
colors instead of solid colors.

Illustrates use of the AlphaComposite class to achieve
transparency with gradient-fill colors.

Draws a 4-inch by 4-inch Frame on the screen.

Translates the orgin to the center of the Frame.

Draws a pair of X and Y-axes centered on the new origin.

Draw a big circle centered on the origin underneath
all of the ellipses.

Uses rotation and translation to fill three ellipses in
each of the four quadrants.  The ellipses intersect at 
their center.  Each is rotated by 60 degrees relative to
the one below it.  The order is:
  Red to green gradient ellipse on the bottom
  Green to blue gradient ellipse in the middle
  Blue to red gradient ellipse on the top
  
TRANSPARENCY
Upper-left quadrant
No transparency

Upper-right quadrant
Red to green is not transparent
Green to blue is not transparent
Blue to red is 50-percent transparent

Lower-left quadrant
Red to green is not transparent
Green to blue is 50-percent transparent
Blue to red is 90-percent transparent

Lower-right quadrant
Red to green is not transparent
Green to blue is 90-percent transparent
Blue to red is 90-percent transparent
  

Whether the dimensions in inches come out right or not
depends on whether the method getScreenResolution()
returns the correct resolution for your screen.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

class Composite02{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class Composite02

class GUI extends Frame{
  int res;//store screen resolution here
  static final int ds = 72;//default scale, 72 units/inch
  static final int hSize = 4;//horizonal size = 4 inches
  static final int vSize = 4;//vertical size = 4 inches
  
  GUI(){//constructor
    //Get screen resolution
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
    //Set Frame size
    this.setSize(hSize*res,vSize*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  //-----------------------------------------------------//
  
  //Override the paint() method
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    Graphics2D g2 = (Graphics2D)g;
    
    //Scale device space to produce inches on the screen
    // based on actual screen resolution.
    g2.scale((double)res/72,(double)res/72);

    //Translate origin to center of Frame
    g2.translate((hSize/2)*ds,(vSize/2)*ds);

    //Draw x-axis
    g2.draw(new Line2D.Double(-1.5*ds,0.0,1.5*ds,0.0));
    //Draw y-axis
    g2.draw(new Line2D.Double(0.0,-1.5*ds,0.0,1.5*ds));
    
    //Draw a big circle underneath all of the ellipses.
    g2.setStroke(new BasicStroke(0.1f*ds));
    Ellipse2D.Double bigCircle = new Ellipse2D.Double(
                            -1.5*ds,-1.5*ds,3.0*ds,3.0*ds);
    g2.draw(bigCircle);

    Ellipse2D.Double theEllipse;


    //Translate origin to upper-left quadrant
    g2.translate(-1.0*ds,-1.0*ds);
    
    //Red to green horizontal ellipse
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.setPaint(new GradientPaint(
                            -1.0f*ds,0.0f*ds,Color.red,
                             1.0f*ds,0.0f*ds,Color.green));
    //Red to green is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);
    
    //Green to blue ellipse at 60 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate(Math.PI/3.0);//rotate 60 degrees
    g2.setPaint(new GradientPaint(
                             -1.0f*ds,0.0f*ds,Color.green,
                              1.0f*ds,0.0f*ds,Color.blue));
    //Green to blue is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);
    
    //Blue to red ellipse at 120 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate((Math.PI/3.0));//rotate 60 more degrees
    g2.setPaint(new GradientPaint(
                              -1.0f*ds,0.0f*ds,Color.blue,
                               1.0f*ds,0.0f*ds,Color.red));
    //Blue to red is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);

    
    //Translate origin to upper-right quadrant
    g2.rotate(-2*(Math.PI/3.0));//undo previous rotation
    g2.translate(2.0*ds,0.0*ds);
    
    //Red to green horizontal ellipse
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.setPaint(new GradientPaint(
                            -1.0f*ds,0.0f*ds,Color.red,
                             1.0f*ds,0.0f*ds,Color.green));
    //Red to green is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);
    
    //Green to blue ellipse at 60 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate(Math.PI/3.0);//rotate 60 degrees
    g2.setPaint(new GradientPaint(
                             -1.0f*ds,0.0f*ds,Color.green,
                              1.0f*ds,0.0f*ds,Color.blue));
    //Green to blue is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);
    
    //Blue to red ellipse at 120 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate((Math.PI/3.0));//rotate 60 more degrees
    g2.setPaint(new GradientPaint(
                              -1.0f*ds,0.0f*ds,Color.blue,
                               1.0f*ds,0.0f*ds,Color.red));
    //Blue to red is 50-percent transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,0.5f));
    g2.fill(theEllipse);


    //Translate origin to lower-left quadrant
    g2.rotate(-2*(Math.PI/3.0));//undo previous rotation
    g2.translate(-2.0*ds,2.0*ds);
    
    //Red to green horizontal ellipse
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.setPaint(new GradientPaint(
                            -1.0f*ds,0.0f*ds,Color.red,
                             1.0f*ds,0.0f*ds,Color.green));
    //Red to green is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);
    
    //Green to blue ellipse at 60 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate(Math.PI/3.0);//rotate 60 degrees
    g2.setPaint(new GradientPaint(
                             -1.0f*ds,0.0f*ds,Color.green,
                              1.0f*ds,0.0f*ds,Color.blue));
    //Green to blue is 50 percent transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,0.5f));
    g2.fill(theEllipse);
    
    //Blue to red ellipse at 120 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate((Math.PI/3.0));//rotate 60 more degrees
    g2.setPaint(new GradientPaint(
                              -1.0f*ds,0.0f*ds,Color.blue,
                               1.0f*ds,0.0f*ds,Color.red));
    //Blue to red is 90-percent transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,0.1f));
    g2.fill(theEllipse);


    //Translate origin to lower-right quadrant
    g2.rotate(-2*(Math.PI/3.0));//undo previous rotation
    g2.translate(2.0*ds,0.0*ds);
    
    //Red to green horizontal ellipse
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.setPaint(new GradientPaint(
                            -1.0f*ds,0.0f*ds,Color.red,
                             1.0f*ds,0.0f*ds,Color.green));
    //Red to green is not transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,1.0f));
    g2.fill(theEllipse);
    
    //Green to blue ellipse at 60 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate(Math.PI/3.0);//rotate 60 degrees
    g2.setPaint(new GradientPaint(
                             -1.0f*ds,0.0f*ds,Color.green,
                              1.0f*ds,0.0f*ds,Color.blue));
    //Green to blue is 90-percent transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,0.1f));
    g2.fill(theEllipse);
    
    //Blue to red ellipse at 120 degrees
    theEllipse = new Ellipse2D.Double(
                           -1.0*ds,-0.25*ds,2.0*ds,0.5*ds);
    g2.rotate((Math.PI/3.0));//rotate 60 more degrees
    g2.setPaint(new GradientPaint(
                              -1.0f*ds,0.0f*ds,Color.blue,
                               1.0f*ds,0.0f*ds,Color.red));
    //Blue to red is 90-percent transparent
    g2.setComposite(AlphaComposite.getInstance(
                            AlphaComposite.SRC_OVER,0.1f));
    g2.fill(theEllipse);

  }//end overridden paint()
    
}//end class GUI
//=======================================================//