/*PaintTexture01.java 12/12/99
Copyright 1999, R.G.Baldwin

Illustrates use of a TexturePaint object to fill a 
relatively large circle with small tiled instances of a 
BufferedImage object.

The BufferedImage object has a red filled circle on a
square green background.

Uses code to create the BufferedImage object to avoid the 
need to provide an auxiliary image file.  

Draws a 4-inch by 4-inch Frame on the screen.

Translates the orgin to the center of the Frame.

Draws a pair of X and Y-axes centered on the new origin.

Fills a 2-inch diameter circle with small tiled versions 
of the BufferedImage object.

Draws the filled 2-inch diameter circle on the Frame, 
centered on the origin.

Whether the dimensions in inches come out right or not
depends on whether the method getScreenResolution()
returns the correct resolution for your screen.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

class PaintTexture01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class PaintTexture01

class GUI extends Frame{
  int res;//store screen resolution here
  static final int ds = 72;//default scale, 72 units/inch
  static final int hSize = 4;//horizonal size = 4 inches
  static final int vSize = 4;//vertical size = 4 inches
  
  GUI(){//constructor
    //Get screen resolution
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
    //Set Frame size
    this.setSize(hSize*res,vSize*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  //-----------------------------------------------------//
  
  //Override the paint() method
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    Graphics2D g2 = (Graphics2D)g;
    
    //Scale device space to produce inches on the screen
    // based on actual screen resolution.
    g2.scale((double)res/72,(double)res/72);

    //Translate origin to center of Frame
    g2.translate((hSize/2)*ds,(vSize/2)*ds);
    
    //Draw x-axis
    g2.draw(new Line2D.Double(-1.5*ds,0.0,1.5*ds,0.0));
    //Draw y-axis
    g2.draw(new Line2D.Double(0.0,-1.5*ds,0.0,1.5*ds));
    
    //Instantiate the main Shape object which is a circle
    Ellipse2D.Double theMainCircle = 
       new Ellipse2D.Double(-1.0*ds,-1.0*ds,2.0*ds,2.0*ds);

    double tileSize = 0.25;//size of tiles in the fill
        
    //Instantiate the anchor rectangle. This determines
    // the size of the tiles containing the BufferedImage
    // when the circle is filled.
    Rectangle2D.Double anchor = 
             new Rectangle2D.Double(0,0,(int)(tileSize*ds),
                                       (int)(tileSize*ds));
    //Instantiate the TexturePaint object and populate it
    // with a BufferedImage object.
    TexturePaint theTexturePaintObj = 
       new TexturePaint(getBufferedImage(),anchor);
       
    g2.setPaint(theTexturePaintObj);//set fill object
    g2.fill(theMainCircle);//do the fill
    g2.draw(theMainCircle);//draw the filled circle

  }//end overridden paint()
  //-----------------------------------------------------//
  
  //Method to create and return a BufferedImage object
  // Returns a BufferedImage consisting of a filled red
  // circle on a green square background.
  BufferedImage getBufferedImage(){
    //Larger images produce better quality.
    double imageSize = 10.0;
    BufferedImage theBufferedImage = 
       (BufferedImage)this.createImage((int)(imageSize*ds),
                                      (int)(imageSize*ds));
    
    //Get a Graphics2D context on the BufferedImage object
    Graphics2D g2dImage = 
                         theBufferedImage.createGraphics();

    //Draw a rectangle on the Graphics2d context on the
    // BufferedImage and fill it with the color green.
    Rectangle2D.Double theRectangle = 
               new Rectangle2D.Double(0.0,0.0,imageSize*ds,
                                             imageSize*ds);
    g2dImage.setPaint(new Color(0,255,0));
    g2dImage.fill(theRectangle);
    g2dImage.draw(theRectangle);

    //Draw a circle on the Graphics2d context on the 
    // BufferedImage and fill it with the color red.
    // This circle will cover the green rectangle.
    Ellipse2D.Double circleOntheBufferedImage = 
                 new Ellipse2D.Double(0.0,0.0,imageSize*ds,
                                             imageSize*ds);
    g2dImage.setPaint(new Color(255,0,0));//red
    g2dImage.fill(circleOntheBufferedImage);
    g2dImage.draw(circleOntheBufferedImage);
    
    return theBufferedImage;

  }//end getBuffered Image
    
}//end class GUI
//=======================================================//