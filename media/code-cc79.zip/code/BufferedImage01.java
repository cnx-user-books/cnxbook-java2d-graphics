/*BufferedImage01.java 12/12/99
Copyright 1999, R.G.Baldwin

Illustrates:
1.  Creating a BufferedImage object from code as an 
    alternative to importing from an image file.
2.  Drawing geometric shapes on the BufferedImage object. 
3.  Drawing the BufferedImage object on a Frame object.

Draws a 4-inch by 4-inch Frame on the screen.

Translates the orgin to the center of the Frame.

Creates a BufferedImage object 3.0 inches on each side.

Gets a Graphics2D context on the BufferedImage

Draws a green filled rectangle on the context that is the
same size as the BufferedImage object.

Draws a red filled circle on the context that just fits 
inside the dimensions of the BufferedImage object.  The
circle cover the green rectangle.

Draws the BufferedImage object on the Frame, centered on 
the origin.

Whether the dimensions in inches come out right or not
depends on whether the method getScreenResolution()
returns the correct resolution for your screen.

Tested using JDK 1.2.2 under WinNT Workstation 4.0
**********************************************************/
import java.awt.geom.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

class BufferedImage01{
  public static void main(String[] args){
    GUI guiObj = new GUI();
  }//end main
}//end controlling class BufferedImage01

class GUI extends Frame{
  int res;//store screen resolution here
  static final int ds = 72;//default scale, 72 units/inch
  static final int hSize = 4;//horizonal size = 4 inches
  static final int vSize = 4;//vertical size = 4 inches
  
  GUI(){//constructor
    //Get screen resolution
    res = Toolkit.getDefaultToolkit().
                                     getScreenResolution();
    //Set Frame size
    this.setSize(hSize*res,vSize*res);
    this.setVisible(true);
    this.setTitle("Copyright 1999, R.G.Baldwin");
    		
    //Window listener to terminate program.
    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
  }//end constructor
  //-----------------------------------------------------//
    
  //Override the paint() method
  public void paint(Graphics g){
    //Downcast the Graphics object to a Graphics2D object
    Graphics2D g2 = (Graphics2D)g;
    
    //Scale device space to produce inches on the screen
    // based on actual screen resolution.
    g2.scale((double)res/72,(double)res/72);

    //Translate origin to center of Frame
    g2.translate((hSize/2)*ds,(vSize/2)*ds);
    
    //Draw x-axis
    g2.draw(new Line2D.Double(-1.5*ds,0.0,1.5*ds,0.0));
    //Draw y-axis
    g2.draw(new Line2D.Double(0.0,-1.5*ds,0.0,1.5*ds));

    double size = 3.0;//size of BufferedImage object
    //Get a BufferedImage object
    BufferedImage bufImg = 
            (BufferedImage)this.createImage((int)(size*ds),
                                           (int)(size*ds));
    
    //Get a Graphics2D context on the BufferedImage object
    Graphics2D g2dImage = bufImg.createGraphics();

    //Draw a rectangle on the BufferedImage and fill it 
    // with the color green.
    Rectangle2D.Double theRectangle = 
           new Rectangle2D.Double(0.0,0.0,size*ds,size*ds);
    g2dImage.setPaint(new Color(0,255,0));//green
    g2dImage.fill(theRectangle);
    g2dImage.draw(theRectangle);

    //Draw a circle on the BufferedImage and fill it with
    // the color red.
    Ellipse2D.Double theCircle = 
             new Ellipse2D.Double(0.0,0.0,size*ds,size*ds);
    g2dImage.setPaint(new Color(255,0,0));//red
    g2dImage.fill(theCircle);
    g2dImage.draw(theCircle);

    //Now draw the BufferedImage on the Frame
    g2.drawImage(bufImg,null,(int)(-(size/2)*ds),
                                      (int)(-(size/2)*ds));

  }//end overridden paint()
    
}//end class GUI
//=======================================================//